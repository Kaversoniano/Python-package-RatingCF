name = "RatingCF"

import RatingCF.ISCF, RatingCF.SCF